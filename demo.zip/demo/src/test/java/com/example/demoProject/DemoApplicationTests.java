package com.example.demoProject;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demoProject.model.Name;
import com.example.demoProject.model.Person;
import com.example.demoProject.model.Ticket;
import com.example.demoProject.model.association.Course;
import com.example.demoProject.model.association.Learner;
import com.example.demoProject.model.association.Score;
import com.example.demoProject.model.association.Embeded.AddressEmbedded;
import com.example.demoProject.model.association.Embeded.PassengerWithEmbeddedFields;
import com.example.demoProject.model.association.Embeded.TicketEmbedded;
import com.example.demoProject.model.association.oneToOne.Department;
import com.example.demoProject.model.association.oneToOne.Manager;
import com.example.demoProject.service.AssociationService;
import com.example.demoProject.service.PersonService;
import com.example.demoProject.service.TicketService;

@SpringBootTest
class DemoApplicationTests {
	@Autowired
	AssociationService associationService;
	
	@Test
	void savePassengerWithEmbeddedObjects() {
	   AddressEmbedded address = new AddressEmbedded();
	   address.setStreet("101");
	   address.setCity("New York");
	   TicketEmbedded ticket1 = new TicketEmbedded();
	   ticket1.setNumber("9898998");
	   TicketEmbedded ticket2 = new TicketEmbedded();
	   ticket2.setNumber("1111111");
	   PassengerWithEmbeddedFields passenger = new PassengerWithEmbeddedFields();
	   passenger.setName("John");
	   passenger.setAddress(address);
	   passenger.addTicket(ticket1);
	   passenger.addTicket(ticket2);
	   passenger.addAttributes("FREQUENT_FLIER", "Yes");
	   passenger.addAttributes("VIP", "No");
	   associationService.savePassengerWithEmbeddedObjects(passenger);
	}
	
	@Test
	public void saveManagerTest() {
		Department department=new Department();
		department.setName("ACCOUNTING");
		Manager manager=new Manager();
		manager.setName("Raj");
		manager.setDepartment(department);
		associationService.saveManagerOneToOneDepartment(manager,department);
	}
	@Test
	public void saveLearnerwithCourseandScore() {
		//Learner1
		Learner learner1=new Learner();
		learner1.setName("John");
		//learner2
		Learner learner2=new Learner();
		learner2.setName("Mary");
		//score1
		Score score1=new Score();
		score1.setMarks(99);
		score1.setSubject("Maths");
		score1.setLearner(learner1);
		//score2
		Score score2=new Score();
		score2.setMarks(90);
		score2.setSubject("Science");
		score2.setLearner(learner1);
		//score3
		Score score3=new Score();
		score3.setMarks(88);
		score3.setSubject("Maths");
		score3.setLearner(learner2);
		//score4
		Score score4=new Score();
		score4.setMarks(88);
		score4.setSubject("Science");
		score4.setLearner(learner2);
		
		learner1.setScores(Arrays.asList(score1,score2));
		learner2.setScores(Arrays.asList(score3,score4));
		
		//Course1
		Course course1=new Course();
		course1.setName("BSC");
		course1.addLearner(learner1);
		course1.addLearner(learner2);
		//course2
		Course course2=new Course();
		course2.setName("BCOM");
		course2.addLearner(learner2);
		course2.addLearner(learner1);
		
		learner1.setCourses(Arrays.asList(course1,course2));
		learner2.setCourses(Arrays.asList(course1,course2));
		
		associationService.saveLearnerOneToManyWithScore(learner1);
		associationService.saveLearnerManyToManyCourse(learner2);
		
		associationService.saveCourseManyToManyLearner(course1);
		associationService.saveCourseManyToManyLearner(course2);
	}
	
	@Test
	public void saveLearnerOneToManyWithScoreTest() {
		//Learner1
		Learner learner1=new Learner();
		learner1.setName("John");
		//learner2
		Learner learner2=new Learner();
		learner2.setName("Mary");
		//score1
		Score score1=new Score();
		score1.setMarks(99);
		score1.setSubject("Maths");
		score1.setLearner(learner1);
		//score2
		Score score2=new Score();
		score2.setMarks(90);
		score2.setSubject("Science");
		score2.setLearner(learner1);
		//score3
		Score score3=new Score();
		score3.setMarks(88);
		score3.setSubject("Maths");
		score3.setLearner(learner2);
		//score4
		Score score4=new Score();
		score4.setMarks(88);
		score4.setSubject("Science");
		score4.setLearner(learner2);
		
		
		learner1.setScores(Arrays.asList(score1,score2));
		learner2.setScores(Arrays.asList(score3,score4));
		
		associationService.saveLearnerOneToManyWithScore(learner1);
		associationService.saveLearnerOneToManyWithScore(learner2);
	}

	/* Day1------------------------------------------------------
	 * @Autowired PersonService personService;
	 * 
	 * @Autowired TicketService ticketService;
	 * 
	 * @Test void test() {
	 * 
	 * }
	 * 
	 * @Test void save_ticketWithCompositeKey_IdClass() { Ticket ticket = new
	 * Ticket(); ticket.setTicketNumber("ticket-number");
	 * ticket.setNumber("number"); ticket.setSeries("series");
	 * ticketService.saveTicket(ticket);
	 * System.out.println("*****************************************");
	 * System.out.println("*****************************************");
	 * System.out.println("*****************************************");
	 * System.out.println("*****************************************");
	 * ticket.setNumber("number-123"); ticketService.saveTicket(ticket);
	 * ticket.setNumber("number"); ticket.setSeries("series-123");
	 * ticketService.saveTicket(ticket); }
	 * 
	 * @Test void save_person_withAddressAndPhone() { Person person = new Person();
	 * Name name=new Name(); name.setFirstName("Shivam"); name.setLastName("Singh");
	 * person.setName(name); person.setCity("New York"); person.setZipCode("1202");
	 * person.setAreaCode("001"); person.setPhoneNumber("89898989");
	 * personService.savePerson(person); Person person2=new Person();
	 * person2.setName(name); person2.setCity("New York");
	 * person2.setZipCode("1202"); person2.setAreaCode("001");
	 * person2.setPhoneNumber("89898989"); personService.savePerson(person2);
	 * 
	 * Person person3=person2; person3.setId(3); personService.savePerson(person3);
	 * 
	 * 
	 * 
	 * }
	 */

	/*
	 * @Test void save_person() { Person person = new Person();
	 * person.setName("abc"); personService.savePerson(person); }
	 */
}
