package com.example.demoProject.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.demoProject.model.Ticket;

@Service
public class TicketService {

	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public
	void saveTicket(Ticket ticket) {
		entityManager.persist(ticket);
	}


}
