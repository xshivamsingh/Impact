package com.example.demoProject.model.association;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;



@Entity
@Table(name="Learner_db")
public class Learner {
	
	@Id
	@GeneratedValue
	int id;
	String name;
	
	@OneToMany(mappedBy = "learner")
	List<Score> scores=new ArrayList<Score>();
	
	@ManyToMany(mappedBy = "learners")
	List<Course> courses=new ArrayList<Course>();

	public List<Course> getCourses() {
		return Collections.unmodifiableList(courses);
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	
	public void addCourse(Course course) {
		this.courses.add(course);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Score> getScores() {
		return Collections.unmodifiableList(scores);
	}

	public void setScores(List<Score> scores) {
		this.scores = scores;
	}
	
	public void addScore(Score score) {
		this.scores.add(score);
	}
}
