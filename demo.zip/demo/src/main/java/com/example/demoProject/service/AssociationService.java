package com.example.demoProject.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.demoProject.model.association.Course;
import com.example.demoProject.model.association.Learner;
import com.example.demoProject.model.association.Embeded.PassengerWithEmbeddedFields;
import com.example.demoProject.model.association.oneToOne.Department;
import com.example.demoProject.model.association.oneToOne.Manager;

@Service
public class AssociationService {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Transactional
	public void saveManagerOneToOneDepartment(Manager manager, Department department) {
		entityManager.persist(manager);
		entityManager.persist(department);
	}
	
	@Transactional
	public void saveLearnerOneToManyWithScore(Learner learner) {
		entityManager.persist(learner);
		learner.getScores().stream().forEach(score->entityManager.persist(score));
	}
	
	@Transactional
	public void saveLearnerManyToManyCourse(Learner learner) {
		entityManager.persist(learner);
		learner.getScores().stream().forEach(score->entityManager.persist(score));
		//learner.getCourses().stream().forEach(course->entityManager.persist(course));
	}
	
	@Transactional
	public void saveCourseManyToManyLearner(Course course) {
		entityManager.persist(course);
	}
	
	@Transactional
	public void savePassengerWithEmbeddedObjects(PassengerWithEmbeddedFields passenger) {
	    System.out.println("savePassengerWithEmbeddedObjects");
	    entityManager.persist(passenger);
	}
	
}
