package com.example.demoProject.model.association.oneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Manager_DB")
public class Manager {
	
	@Id
	@GeneratedValue
	private int managerId;
	
	private String name;
	
	@OneToOne
	@JoinTable(name = "MANAGER_TO_DEPARTMENT",
		    joinColumns = {
		            @JoinColumn (name = "Manager_ID", referencedColumnName = "managerId")
		           },
		    inverseJoinColumns = {
		            @JoinColumn (name = "Department_ID", referencedColumnName = "departmentId")
		        })
	private Department department;

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
}
