package com.example.demoProject.model.association;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Course_db")
public class Course {
	
	@Id
	@GeneratedValue
	@Column(name = "course_id")
	int id;
	
	@Column(name = "course_name")
	String name;
	
	@ManyToMany
	List<Learner> learners=new ArrayList<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Learner> getLearners() {
		return Collections.unmodifiableList(learners);
	}

	public void setLearners(List<Learner> learners) {
		this.learners = learners;
	}
	
	public void addLearner(Learner learner) {
		this.learners.add(learner);
	}
	
	

}
