package com.example.demoProject.model;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "Person_DB")
@SecondaryTables(value = { @SecondaryTable(name = "address",
pkJoinColumns = @PrimaryKeyJoinColumn(name = "emp_id",
referencedColumnName = "p_id")),
@SecondaryTable(name = "phone",
pkJoinColumns = @PrimaryKeyJoinColumn(name = "emp_id",
referencedColumnName = "p_id")),
})

public class Person {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "p_id", columnDefinition = "varchar (23)")
	int id;
	
	@Embedded //to store composite keys
	@Column(name = "p_name")
	Name name;
	
	//using secondaryTable
	@Column(name = "city", table = "address", columnDefinition = "varchar(50) not null")
    private String city; // NY City //this column won't be displayed inside prson_tb table
    @Column(name = "zip_code", table = "address", columnDefinition = "varchar(50) not null")
    private String zipCode; // 1234 //this column won't be displayed inside prson_tb table
    @Column(name = "area_code", table = "phone", columnDefinition = "varchar(50) not null")
    private String areaCode; // 001//this column won't be displayed inside prson_tb table
    @Column(name = "phone_number", table = "phone", columnDefinition = "varchar(50) not null")
    private String phoneNumber; // 001
	
	
	
	public Person() {
		// TODO Auto-generated constructor stub
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public Name getName() {
		return name;
	}



	public void setName(Name name) {
		this.name = name;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getZipCode() {
		return zipCode;
	}



	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}



	public String getAreaCode() {
		return areaCode;
	}



	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}



	public String getPhoneNumber() {
		return phoneNumber;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", city=" + city + ", zipCode=" + zipCode + ", areaCode="
				+ areaCode + ", phoneNumber=" + phoneNumber + "]";
	}

	
	
}
