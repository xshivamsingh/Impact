package com.example.demoProject.model.association.Embeded;

import javax.persistence.Embeddable;

@Embeddable
public class TicketEmbedded {
	
	private String number;
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
