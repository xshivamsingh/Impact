package com.example.demoProject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "ticket_composite")
@IdClass(TicketCompositeKeyIdClass.class)
public class Ticket {

	@Id
	@Column(name = "t_compositeKeyID")
	private String number;
	private String series;
	
	@Column(name = "t_Number")
	private String ticketNumber;

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
}
