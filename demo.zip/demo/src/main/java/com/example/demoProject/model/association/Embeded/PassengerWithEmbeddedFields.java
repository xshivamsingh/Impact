package com.example.demoProject.model.association.Embeded;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;

@Entity
public class PassengerWithEmbeddedFields {

    @Id
    @GeneratedValue
    private int id;
    private String name;
    @Embedded
    @AttributeOverrides({
	   @AttributeOverride(name = "street",column = @Column(name="PASS_STREET")),
	   @AttributeOverride(name = "city",column = @Column(name="PASS_CITY")),
   })
    private AddressEmbedded address;
    
    @ElementCollection
    @CollectionTable(name = "PASS_TICKET",
    				joinColumns = {
    						@JoinColumn(name="PASS_ID",referencedColumnName = "ID")
    				})
    private List<TicketEmbedded> ticketList = new ArrayList<>();
    
    @ElementCollection
    @MapKeyColumn(name = "ATTR_NAME")
    @Column(name = "ATTR_VALUE")
    @CollectionTable(name = "PASS_ATTR",
    joinColumns = {
            @JoinColumn(name = "PASS_ID", referencedColumnName = "ID")
    })
    private Map<String, String> attributes = new HashMap<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AddressEmbedded getAddress() {
		return address;
	}

	public void setAddress(AddressEmbedded address) {
		this.address = address;
	}

	public List<TicketEmbedded> getTicketList() {
		return ticketList;
	}
	
	public void addTicket(TicketEmbedded ticket) {
		this.ticketList.add(ticket);
	}
	
	public void setTicketList(List<TicketEmbedded> ticketList) {
		this.ticketList = ticketList;
	}

	public Map<String, String> getAttributes() {
		return attributes;
	}

	public void setAttributes(Map<String, String> attributes) {
		this.attributes = attributes;
	}
    
    public void addAttributes(String key,String value) {
		this.attributes.put(key, value);
	}
	
}