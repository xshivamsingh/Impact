package JunitDay2;

public class StudentDao {
	
	
	public Student getStudentInfo(String name) {
		// DB call
		
		throw new RuntimeException("No DB found");
	}
}
