package JunitDay2;

public class StudentDaoStub extends StudentDao{
	
	
	public Student getStudentInfo(String name) {
	Student student=new Student("abc", 17);
	return student; //stub data
	}
	
}
