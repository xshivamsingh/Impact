package JunitDay2;

import java.util.Random;

import com.mavenProj.JavaEnhan.Assig1.User;

public class StudentService {
	
	StudentService(){
		super();
	}
	private StudentDao studentDao = new StudentDao();
	
	public StudentService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}

	Student getStudent(String name) {
		
		
		return studentDao.getStudentInfo(name);
	}
	
	String isEligibleToVote(int age) {
		
		if(age>=18) return "eligible to vote";
		return "not eligible to vote";
		
	}
	
	boolean isEven(int x) {
		return x%2==0;
		
	}
	
	int randomInt() {
		Random random=new Random();
		int x=random.ints(1,100).findAny().getAsInt();
		return x;
	}
}
