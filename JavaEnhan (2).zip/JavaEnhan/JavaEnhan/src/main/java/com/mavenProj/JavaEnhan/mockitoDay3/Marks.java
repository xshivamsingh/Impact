package com.mavenProj.JavaEnhan.mockitoDay3;

public class Marks {
	
	private String subject;
    private long marks;
    
    public Marks(String subject, long marks) {
        this.subject = subject;
        this.marks = marks;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public long getMarks() {
        return marks;
    }

    public void setMarks(long marks) {
        this.marks = marks;
    }

}
