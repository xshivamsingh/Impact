package com.mavenProj.JavaEnhan.mockitoDay3;

import java.util.List;

public class StudentService {
	
	List<Marks> getMarks(long id) {
		return null;
	}
	
	boolean isValid(long id) {
		
		return true;
	}
	

}
