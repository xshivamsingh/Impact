package com.mavenProj.JavaEnhan.lambda;

public interface FunctInterface {

	public String myMethod(String a);
}
