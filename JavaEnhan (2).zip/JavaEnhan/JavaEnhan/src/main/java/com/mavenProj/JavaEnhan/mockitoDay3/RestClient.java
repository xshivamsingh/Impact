package com.mavenProj.JavaEnhan.mockitoDay3;

public class RestClient {

}
