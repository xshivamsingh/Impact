package com.mavenProj.JavaEnhan.mockitoDay3;

import java.util.List;

public class ExamService {
	
	private final StudentService studentService;
    private final RestClient restClient;
    public ExamService(StudentService studentService, RestClient restClient) {
        this.studentService = studentService;
        this.restClient = restClient;
    }

    public boolean hasStudentPassed(long id) {
        List<Marks> marks = studentService.getMarks(id);
        long count = marks.stream()
                .filter(m -> m.getMarks() <40)
                .count();
        if (count >=2) {
            System.out.println(String.format("Student %s failed", id));
            return false;
        }
        return studentService.isValid(id);
    }
    
    public boolean hasScoredFullMarksInAtleastOneSubject(long id) {
    	List<Marks> marks=studentService.getMarks(id);
    	long count = marks.stream().filter(x->x.getMarks()==100).count();
    	if(count>0) return true;
    	return false;
		
	}

}
