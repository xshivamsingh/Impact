package com.mavenProj.JavaEnhan.Assig1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserTest extends User {

	static User u;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		u=new User();
		System.out.println("inside set all:\n"+u);
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
		u=null;
		System.out.println("inside after all:\n"+u);
		
	}

	@BeforeEach
	void setUp() throws Exception {
		u.setName("Bhagat");
		u.setAge(17);
		System.out.println("inside set each:\n"+u);
	}

	@AfterEach
	void tearDown() throws Exception {
		
	}

	@Test
	void testUser() {
		//fail("Not yet implemented");
	}

	@Test
	void testGetAge_SetAge() {
		
		assertEquals(17, u.getAge());
		
	}

	@Test
	void test_SetName_GetName() {
		
		assertEquals("Bhagat", u.getName());
	}
	
}
