package com.mavenProj.JavaEnhan.junit5Mockito;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	CalculatorHelper c = new CalculatorHelper();
	Calculator calculator = new Calculator(c);
	/*
	 * @BeforeAll static void setUpBeforeClass() throws Exception { }
	 * 
	 * @AfterAll static void tearDownAfterClass() throws Exception { }
	 * 
	 * @BeforeEach void setUp() throws Exception { }
	 * 
	 * @AfterEach void tearDown() throws Exception { }
	 */

	@Test
	@Order(1)
	void testAdd_sociable() {
		long result = calculator.add(10, 20);
		assertEquals(34, result);
	}

	@Test
	@Order(3)
	void test_subtract() {
		long result = calculator.subtract(20, 40);
		assertEquals(-20, result);

	}

	@Test
	@Order(0)
	void test_multiply() {
		long result = calculator.multiply(20, 40);
		assertEquals(800, result);

	}

	@Test
	@Order(2)
	void test_divide() {
		double result = calculator.divide(20, 10);
		assertEquals(2, result);
	}
	
	@Test
	@Order(4)
	void test_divide_case2() {
		RuntimeException actualException = assertThrows(RuntimeException.class, ()->calculator.divide(20, 0));
		assertTrue(actualException.getMessage().equals("Divide by zero"));
		//System.out.print(actualException);
	}
	/*
	 * @Test void testAdd_solitary() { CalculatorHelper
	 * calculatorHelper=Mockito.mock(CalculatorHelper.class); Calculator
	 * calculator=new Calculator(calculatorHelper); long result=calculator.add(10,
	 * 20); assertEquals(34, result); }
	 * 
	 * @Test void testAdd_solitary_withbehaviour() { CalculatorHelper
	 * calculatorHelper=Mockito.mock(CalculatorHelper.class);
	 * Mockito.when(calculatorHelper.enrich(ArgumentMatchers.anyLong())).thenReturn(
	 * 10L); Calculator calculator=new Calculator(calculatorHelper); long
	 * result=calculator.add(10, 20); assertEquals(34, result); }
	 */

}
