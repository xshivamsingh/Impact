package com.mavenProj.JavaEnhan.junit5Mockito;

public class Calculator {
	
	CalculatorHelper calculatorHelper;
	
	public Calculator(CalculatorHelper calculatorHelper) {
		super();
		this.calculatorHelper = calculatorHelper;
	}
	
	/*
	 * public long add(long a, long b) { long c=calculatorHelper.enrich(a); long
	 * d=calculatorHelper.enrich(b); return c+d;
	 * 
	 * }
	 */
	public long add(long a, long b) {
		long c = calculatorHelper.enrich(a);
		long d = calculatorHelper.enrich(b);
		return c+d;
		
	}
	public long subtract(long a,long b) {
		
		return a-b;
	}
	public long multiply(long a,long b) {
		
		return a*b;
	}
	public double divide(int a,int b) {
		if(b==0) {
			throw new RuntimeException("Divide by zero");
		}
		else
			return a/b;
	}
}
