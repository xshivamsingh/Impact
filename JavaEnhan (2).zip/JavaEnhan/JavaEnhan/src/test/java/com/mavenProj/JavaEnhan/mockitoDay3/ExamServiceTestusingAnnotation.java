package com.mavenProj.JavaEnhan.mockitoDay3;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ExamServiceTestusingAnnotation {

	@Mock
	private static StudentService studentService;
	@Mock
	private static RestClient restClient;
	
	
	@InjectMocks
	private ExamService examService;
	
	@Test
	public void TesthasStudentPassed() {
		List<Marks> marks=Arrays.asList(new Marks("Science", 100),new Marks("Maths", 56));
		Mockito.when(studentService.getMarks(2)).thenReturn(marks);
		boolean hasScoredFullmarks=examService.hasScoredFullMarksInAtleastOneSubject(2);
		assertTrue(hasScoredFullmarks);
	}
	   
}
