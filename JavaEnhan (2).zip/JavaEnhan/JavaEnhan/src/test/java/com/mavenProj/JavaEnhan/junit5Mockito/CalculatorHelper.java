package com.mavenProj.JavaEnhan.junit5Mockito;

public class CalculatorHelper {
	
	public long enrich(long x) {
		
		return x+2;
		
	}
}
