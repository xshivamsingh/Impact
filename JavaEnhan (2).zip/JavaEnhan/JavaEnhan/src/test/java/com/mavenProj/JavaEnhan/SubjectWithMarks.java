package com.mavenProj.JavaEnhan;

public class SubjectWithMarks {

	String subj;
	int marks;
	public String getSubj() {
		return subj;
	}
	public void setSubj(String subj) {
		this.subj = subj;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "SubjectWithMarks [subj=" + subj + ", marks=" + marks + "]";
	}
	public SubjectWithMarks(String subj, int marks) {
		super();
		this.subj = subj;
		this.marks = marks;
	}
}
