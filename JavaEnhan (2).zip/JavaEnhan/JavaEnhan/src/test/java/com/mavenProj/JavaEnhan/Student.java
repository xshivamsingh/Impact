package com.mavenProj.JavaEnhan;

public class Student {
int id,age, marks;
String name;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Student(int id, int age, int marks, String name) {
	super();
	this.id = id;
	this.age = age;
	this.marks = marks;
	this.name = name;
}
@Override
public String toString() {
	return "Student [id=" + id + ", age=" + age + ", marks=" + marks + ", name=" + name + "]";
}

}
