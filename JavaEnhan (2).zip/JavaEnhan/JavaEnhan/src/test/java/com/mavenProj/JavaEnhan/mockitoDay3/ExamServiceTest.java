package com.mavenProj.JavaEnhan.mockitoDay3;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class ExamServiceTest {

	 @Test
	    void shouldPassIfMarksObtainedIsNotLessThanFourtyInTwoOrMoreSubjects() {
	        StudentService spyStudentServiceMock = Mockito.spy(StudentService.class);
	        RestClient restClientMock = Mockito.mock(RestClient.class);
	        List<Marks> marks = Arrays.asList(new Marks("Maths", 50), new Marks("Science", 50));
	        Mockito.when(spyStudentServiceMock.getMarks(2)).thenReturn(marks);
	        ExamService examServiceUT = new ExamService(spyStudentServiceMock, restClientMock);
	        boolean hasStudentPassed = examServiceUT.hasStudentPassed(2);
	        assertTrue(hasStudentPassed);
	        Mockito.verify(spyStudentServiceMock,Mockito.times(1)).isValid(2);
	    }

	    @Test
	    void shouldFailIfMarksObtainedIsLessThanFiftyInTwoOrMoreSubjects() {
	        StudentService studentServiceMock = Mockito.mock(StudentService.class);
	        RestClient restClientMock = Mockito.mock(RestClient.class);
	        List<Marks> marks = Arrays.asList(new Marks("Maths", 49), new Marks("Science", 40));
	        Mockito.when(studentServiceMock.getMarks(2)).thenReturn(marks);
	        ExamService examServiceUT = new ExamService(studentServiceMock, restClientMock);
	        boolean hasStudentPassed = examServiceUT.hasStudentPassed(2);
	        assertFalse(hasStudentPassed,()->"Student failed");
	    }
	    
	    @Test
	    void TestMethodhasScoredFullMarksInAtleastOneSubject() {
	    	StudentService studentServiceMock = Mockito.mock(StudentService.class);
	    	RestClient restClientMock = Mockito.mock(RestClient.class);
	        List<Marks> marks = Arrays.asList(new Marks("Maths", 100), new Marks("Science", 40));
	        Mockito.when(studentServiceMock.getMarks(5)).thenReturn(marks);
	        ExamService examService = new ExamService(studentServiceMock, restClientMock);
	    	boolean hasScoredFullmarks=examService.hasScoredFullMarksInAtleastOneSubject(5);
	    	assertTrue(hasScoredFullmarks);
	    	
	    	
	    }

	   
}
