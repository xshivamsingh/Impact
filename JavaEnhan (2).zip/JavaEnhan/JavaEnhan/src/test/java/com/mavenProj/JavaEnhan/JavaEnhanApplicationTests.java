package com.mavenProj.JavaEnhan;

import org.junit.jupiter.api.Test;
import org.omg.CORBA.Current;
import org.springframework.lang.Nullable;

import static org.assertj.core.api.Assertions.offset;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.xpath;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//@SpringBootTest
class JavaEnhanApplicationTests {
	
	/*
	 * @Test public void UserTest(){ List<String> nickNameList1
	 * =Arrays.asList("sanju","arun","goli"); Optional<List<String>>
	 * list1=Optional.ofNullable(nickNameList1); List<String> nickNameList2=null;
	 * Optional<List<String>> list2=Optional.ofNullable(nickNameList2); User
	 * user2=new User("sachin", list2); User user1=new User("sachin", list1);
	 * System.out.println(user1); System.out.println(user2);
	 * 
	 * //List<String> l2=user2.getNickNameList().orElse(new ArrayList<>());
	 * 
	 * System.out.println("after sorting:\n"+sortList(user1));
	 * System.out.println(sortList(user2));
	 * 
	 * } public List<String> sortList(User x){ return x.getNickNameList()
	 * .orElse(new ArrayList<>()) .stream() .sorted() .collect(Collectors.toList());
	 * }
	 */

	/*
	 * @Test void dateTimeApi() { Instant now=Instant.now();
	 * System.out.println(now); now.plusSeconds(100000);
	 * System.out.println("After plus operation: "+now); }
	 */

	/*
	 * @Test void zonedDateTime_zoneChange() { ZonedDateTime now =
	 * ZonedDateTime.now(); System.out.println(now); ZonedDateTime usTime =
	 * now.withZoneSameInstant(ZoneId.of("US/Central")); System.out.println(usTime);
	 * }
	 * 
	 * @Test void zonedDateTime() { ZonedDateTime now = ZonedDateTime.now();
	 * System.out.println(now); System.out.println(now.getYear());
	 * System.out.println(now.getMonth()); System.out.println(now.getDayOfMonth());
	 * System.out.println(now.getHour()); System.out.println(now.getMinute());
	 * System.out.println(now.getSecond()); System.out.println(now.getNano()); }
	 * 
	 * @Test void localDateTime() { LocalDateTime now = LocalDateTime.now();
	 * System.out.println(now); System.out.println(now.getYear());
	 * System.out.println(now.getMonth()); System.out.println(now.getDayOfMonth());
	 * System.out.println(now.getHour()); System.out.println(now.getMinute());
	 * System.out.println(now.getSecond()); System.out.println(now.getNano()); }
	 * 
	 * @Test void localTime() { LocalTime now = LocalTime.now();
	 * System.out.println(now); System.out.println(now.getHour());
	 * System.out.println(now.getMinute()); System.out.println(now.getSecond());
	 * System.out.println(now.getNano()); }
	 * 
	 * 
	 *//**
		 * Instant -> LocalDate Duration -> Period
		 *//*
			 * @Test void localDate() { LocalDate now = LocalDate.now();
			 * System.out.println(now); LocalDate previousDate = LocalDate.of(2019,
			 * Month.OCTOBER, 24); System.out.println(previousDate); Period dateDuration =
			 * Period.between(now, previousDate); System.out.println(dateDuration);
			 * System.out.println(dateDuration.getDays());
			 * System.out.println(dateDuration.getMonths());
			 * System.out.println(dateDuration.getYears()); System.out.println("****"); long
			 * days = ChronoUnit.DAYS.between(previousDate, now); System.out.println(days);
			 * }
			 * 
			 * @Test void duration_calculateTotalTime() { Duration duration =
			 * Duration.ofDays(5); System.out.println(duration);
			 * System.out.println(duration.getSeconds());
			 * System.out.println(Duration.ofMinutes(5)); Duration durationSeconds =
			 * Duration.ofSeconds(400); System.out.println(durationSeconds);
			 * System.out.println(durationSeconds.getSeconds());
			 * System.out.println(durationSeconds.getNano()); }
			 * 
			 * @Test void instant_calculateTotalTime() throws InterruptedException { Instant
			 * start = Instant.now(); System.out.println(start); method(); Instant end =
			 * Instant.now(); Duration totalTime = Duration.between(start, end);
			 * System.out.println(totalTime); System.out.println(totalTime.getNano()); }
			 * 
			 * private void method() throws InterruptedException { Thread.sleep(500); }
			 * 
			 * @Test void instant() { Instant now = Instant.now(); System.out.println(now);
			 * Instant instant = now.minusSeconds(5000); System.out.println(instant); }
			 */

	/*
	 * @Test void optionalusage() { Optional<String>
	 * s=Optional.ofNullable(getString(1)); if(s.isPresent())
	 * System.out.println("Value is present");
	 * s.ifPresent(x->System.out.println(x));
	 * 
	 * System.out.println(s.orElse("or else executed"));
	 * System.out.println(s.orElseGet(()->{ return "or else get executed";}));
	 * //s.orElseThrow(()-> { // return new RuntimeException("MyExecption"); //});
	 * 
	 * Optional<Object> s2 = s.empty(); System.out.println(s+" "+s2);
	 * 
	 * String upperString= s.toString().toUpperCase();
	 * System.out.println(upperString); } public String getString(int n) {
	 * if(n%2==0) return "welcome"; return null; }
	 */
	/*
	 * //Day2-----------------------------------------------------------------------
	 * --------- //using flatmap
	 * 
	 * @Test public void flatstream() { List<StudentWithSubject>
	 * studentList=Arrays.asList( new StudentWithSubject(1, 17, "sachin",
	 * Arrays.asList(new SubjectWithMarks("Science", 99),new
	 * SubjectWithMarks("Maths",88))), new StudentWithSubject(1, 17, "hitesh",
	 * Arrays.asList(new SubjectWithMarks("Science", 55),new
	 * SubjectWithMarks("Maths",63))), new StudentWithSubject(1, 17, "ram",
	 * Arrays.asList(new SubjectWithMarks("Science", 45),new
	 * SubjectWithMarks("Maths",97))));
	 * 
	 * 
	 * Stream<List<SubjectWithMarks>>
	 * subjectAndsmarklist=studentList.stream().map(a->a.getS());
	 * 
	 * Stream<SubjectWithMarks> s=subjectAndsmarklist.flatMap(x->x.stream());
	 * 
	 * List<Integer> marksList=
	 * s.map(x->x.getMarks()).sorted().collect(Collectors.toList());
	 * System.out.print(marksList); }
	 */

	/*
	 * @Test public void streamUsage() { List<Student> students = Arrays.asList(new
	 * Student(1, 16, 77, "xyz"), new Student(2, 17, 99, "abc"), new Student(4, 20,
	 * 89, "rzap")); List<String> snames = students.stream().map(x ->
	 * x.getName()).sorted().collect(Collectors.toList());
	 * 
	 * List<Integer> sortedMarks = students.stream().map(x ->
	 * x.getMarks()).sorted().collect(Collectors.toList()); String name1 =
	 * students.stream().sorted((s1, s2) -> Integer.compare(s2.getMarks(),
	 * s1.getMarks())).findFirst() .map(s -> s.getName()).get();
	 * 
	 * String name2 = students.stream().sorted((s1, s2) ->
	 * Integer.compare(s1.getMarks(), s2.getMarks())).findFirst() .map(s ->
	 * s.getName()).get();
	 * 
	 * double avg = students.stream().map(x -> x.getMarks()).mapToLong(x ->
	 * x).average().getAsDouble();
	 * 
	 * System.out.println("sortedNames:" + snames + "\nsorted MArks:" + sortedMarks
	 * + "\nstudent with max marks: " + name1 + "\nstudentWithminMarks: " + name2 +
	 * "\naverageMarks: " + avg);
	 * 
	 * }
	 */

	/*
	 * @Test public void minMaxAvgStreams() { int[] a= {3,2,1,4}; int
	 * min=IntStream.of(a).min().getAsInt(); int
	 * max=IntStream.of(a).max().getAsInt(); int avg=(int)
	 * IntStream.of(a).average().getAsDouble();
	 * System.out.print(min+" "+max+" "+avg); }
	 */

	/*
	 * @Test public void stringStreamsort() { List<String>
	 * s=Arrays.asList("hello ","how are u","bye"); s.stream().sorted((a,b)->{
	 * return a.length()-b.length(); }).forEach(System.out::println);
	 * 
	 * }
	 */

	/*
	 * @Test public void intstream_max(){ int[]a= {1,4,2,2}; IntStream
	 * s=IntStream.of(a); System.out.println(s.max());
	 * System.out.println(IntStream.of(a).min());
	 * 
	 * 
	 * }
	 */

	/*
	 * @Test public void stream_Test(){ String[] a= {"abc","efg","lal"};
	 * Stream<String> s=Stream.of(a);
	 * s.filter(x->x.startsWith("l")).forEach(System.out::println);
	 * 
	 * }
	 */
	/*
	 * Day1 -------------------------------------------------------
	 * 
	 * @Test void sortUser() { List<User> u=new ArrayList<User>(); u.add(new
	 * User("xyz",22)); u.add(new User("abc",22)); u.add(new User("xyz",23));
	 * u.add(new User("lmn",22)); System.out.println("Before sorting:");
	 * u.forEach(a->System.out.println(a));
	 * 
	 * Comparator<User> nameComparator=(x,y)->{ return
	 * x.getName().compareTo(y.getName()); }; Comparator<User>
	 * ageComparator=(m,n)->Integer.compare(m.getAge(),n.getAge()); Comparator<User>
	 * c=nameComparator.thenComparing(ageComparator); Collections.sort(u,c);
	 * System.out.println("After sorting by name:"); System.out.print(u); }
	 */

	/*
	 * @Test void consumerTest() {
	 * 
	 * Consumer<String> c=a->{ System.out.print(a); }; c.accept("Hello");
	 * 
	 * }
	 * 
	 * @Test void supplierTest() { Supplier<String> s=()->{ return
	 * "Supplier example"; }; s.get();
	 * 
	 * }
	 * 
	 * @Test void predicateTest() { Predicate<Integer> p=a->{ if(a>=18) return true;
	 * else return false; }; System.out.println(p.test(21));
	 * System.out.println(p.test(17)); }
	 * 
	 * @Test void funstionTest(){ Function<String, String> f=a->{ return
	 * a.toLowerCase();
	 * 
	 * }; }
	 * 
	 * @Test void RunnableTest(){ Runnable r=()->{
	 * System.out.println("inside runnable"); }; Thread t1=new Thread(r);
	 * t1.start(); }
	 */

	// using anonymous class
	/*
	 * @Test void contextLoads() { FunctInterface f= new FunctInterface() {
	 * 
	 * @Override public String myMethod(String a) { // TODO Auto-generated method
	 * stub return a.toUpperCase(); } }; String a=f.myMethod("hello World");
	 * System.out.println(a);
	 * 
	 * } //using Lamda
	 * 
	 * @Test void contextLoads2() { FunctInterface f2= a->a.toUpperCase();
	 * System.out.println(f2.myMethod("jai hind")); //FunctInterface f2=(String
	 * a)->a.toUpperCase(); //using method reference FunctInterface
	 * f3=String::toUpperCase; System.out.println(f3.myMethod("jai hind2")); };
	 */
}
