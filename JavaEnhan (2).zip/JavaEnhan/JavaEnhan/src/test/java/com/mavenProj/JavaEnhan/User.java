package com.mavenProj.JavaEnhan;

import java.util.List;
import java.util.Optional;

public class User {
String name;
Optional<List<String>> nickNameList;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Optional<List<String>> getNickNameList() {
	return nickNameList;
}
public void setNickNameList(Optional<List<String>> nickNameList) {
	this.nickNameList = nickNameList;
}
@Override
public String toString() {
	return "User [name=" + name + ", nickNameList=" + nickNameList + "]";
}
public User(String name, Optional<List<String>> nickNameList) {
	super();
	this.name = name;
	if(nickNameList.isPresent()) 
	this.nickNameList = nickNameList;
	else {
		this.nickNameList=Optional.empty();
	}
}

}
