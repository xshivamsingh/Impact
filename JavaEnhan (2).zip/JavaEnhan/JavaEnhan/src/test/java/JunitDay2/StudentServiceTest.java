package JunitDay2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

@TestMethodOrder(OrderAnnotation.class)
class StudentServiceTest {

	/*
	 * @BeforeAll static void setUpBeforeClass() throws Exception { }
	 * 
	 * @AfterAll static void tearDownAfterClass() throws Exception { }
	 * 
	 * @BeforeEach void setUp() throws Exception { }
	 * 
	 * @AfterEach void tearDown() throws Exception { }
	 */
	
	@Order(3)
	@Test
	@DisplayName("Get student details: Order3")
	@Tag("testJunit")
	void getStudent_test() {
		StudentService s = new StudentService(new StudentDaoStub());
		Student student = s.getStudent("abc");
		assertEquals("abc", student.getName());
	}
	
	@Order(2)
	@Test
	@DisplayName("Get student details test: Order2")
	@Tag("testJunit")
	void getStudent_name_startingWith_a_test() {
		StudentService s = new StudentService(new StudentDaoStub());
		Student student = s.getStudent("xyz");
		assertEquals("abc", student.getName(), () -> "getStudent test failed");

	}
	
	@Order(1)
	@Test
	@DisplayName("check student vote eligibility: Order1")
	@Tag("testJunit")
	void test_isEligibleToVote() {
		StudentService s = new StudentService(new StudentDaoStub());
		Student student = new Student();
		student.setAge(19);
		String result = s.isEligibleToVote(student.getAge());
		assertAll(() -> {
					assertEquals("eligible to vote", result);
					},
					() -> {
					assertEquals(19, student.getAge(), () -> "get Age failed");
				});
	}

	@DisplayName("Nested Testing")
	@Nested
	@TestMethodOrder(OrderAnnotation.class)
	class NestedTesting {

		@Timeout(1)
		@RepeatedTest(value = 5, name = "{displayName} {currentRepetition} / {totalRepetitions}")
		@Order(2)
		//@DisplayName("Repeated Test")
		@Tag("testJunit1")
		void test() {
			StudentService service = new StudentService();
			assertTrue(service.isEven(service.randomInt()));
		}
		
		
		@ParameterizedTest
		@Order(1)
		@ValueSource(ints = { 1, 4, 10, 6 })
		@DisplayName("Parameterized Test")
		@Tag("testJunit1")
		void Test3(int i) {
			StudentService service = new StudentService();
			assertTrue(service.isEven(i));
		}
	}
}
